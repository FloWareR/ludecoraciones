<?php

class miclase_clase 
{
  public $test;
  
  public function __construct() {
    
  }
}

?>