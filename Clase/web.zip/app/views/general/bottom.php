
  <div class="footer"> 

    <div class="footer-column"> 
      <h2><strong>SHOP</strong></h2> 
      <ul> 
        <li><h4>Carrito</h4></li> 
        <li><h4>Mis Pedidos</h4></li> 
        <li><h4>Devoluciones</h4></li> 
      </ul> 
    </div> 

    <div class="footer-column"> 
      <h2><strong>NOSOTROS</strong></h2> 
      <ul> 
        <li><h4>Fancy Logo</h4></li> 
      </ul> 
    </div> 

    <div class="footer-column"> 
      <h2><strong>AYUDA</strong></h2> 
      <ul> 
        <li><h4>Contacto</h4></li> 
      </ul> 
    </div> 

    <div class="divider2">
    </div> 

    <div class="social-media"> 
      <h2><strong>¡SÍGUENOS!</strong></h2> 
      <div class="social-media-icons"> 
        <a href="#"><i class="fab fa-facebook"></i></a> 
        <a href="#"><i class="fab fa-instagram"></i></a> 
        <a href="#"><i class="fab fa-twitter"></i></a> 
        <a href="#"><i class="fab fa-tiktok"></i></a> 
        <a href="#"><i class="fab fa-youtube"></i></a> 
      </div> 
      <button class="newsletter-button">Newsletter</button> 
    </div> 
  </div>
</body>
</html>